#!/usr/bin/env python3
import rospy
from gazebo_msgs.msg import ModelState
from gazebo_msgs.srv import SetModelState
import math

def move_obstacle():
    rospy.init_node('dynamic_obstacle_mover')
    rospy.wait_for_service('/gazebo/set_model_state')
    
    set_state = rospy.ServiceProxy('/gazebo/set_model_state', SetModelState)
    
    # ⚠️ 注意：请看 Gazebo 左侧 'Models' 列表
    # 您的障碍物可能叫 'unit_box', 'unit_box_0' 或 'unit_cylinder'
    # 请根据实际情况修改下面的名字
    model_name = 'unit_box' 
    
    # 控制循环频率
    rate = rospy.Rate(10) # 10Hz
    t = 0.0
    
    print(f"启动动态障碍物 (慢速模式)... 目标模型: {model_name}")

    while not rospy.is_shutdown():
        state = ModelState()
        state.model_name = model_name
        
        # 障碍物运动中心点 
        # (建议把这改到机器人必经之路的坐标上)
        center_x = 2.0
        center_y = 0.0
        
        # 运动半径 (米)
        radius = 1.0
        
        # 让障碍物做圆周运动
        state.pose.position.x = center_x + radius * math.sin(t)
        state.pose.position.y = center_y + radius * math.cos(t)
        state.pose.position.z = 0.5
        
        # 保持方块不倒
        state.pose.orientation.w = 1.0
        
        try:
            set_state(state)
        except rospy.ServiceException as e:
            # 刚启动可能找不到模型，忽略报错
            pass
            
        # === 速度控制核心 ===
        # 原来是 0.1，改为 0.03
        # 这个数字越小，障碍物移动越慢
        t += 0.03 
        
        rate.sleep()

if __name__ == '__main__':
    try:
        move_obstacle()
    except rospy.ROSInterruptException:
        pass
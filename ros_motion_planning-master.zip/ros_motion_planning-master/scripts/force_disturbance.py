#!/usr/bin/env python3
import rospy
import random
from gazebo_msgs.srv import ApplyBodyWrench
from geometry_msgs.msg import Wrench, Point

def apply_disturbance():
    rospy.init_node('wind_generator', anonymous=True)
    # 等待Gazebo的服务准备好
    rospy.wait_for_service('/gazebo/apply_body_wrench')
    apply_wrench = rospy.ServiceProxy('/gazebo/apply_body_wrench', ApplyBodyWrench)

    rate = rospy.Rate(1) # 1Hz，每秒推一次
    
    print("开始施加侧向风干扰... (模拟洋流/大风)")

    while not rospy.is_shutdown():
        try:
            wrench = Wrench()
            # 【核心干扰】：在 Y 轴（侧向）施加随机力
            # 假设机器人车头朝 X，侧向风会让它跑偏
            force_mag = random.uniform(2.0, 3.0) # 力的大小
            direction = 1 if random.random() > 0.5 else -1
            
            wrench.force.y = force_mag * direction 
            wrench.force.x = random.uniform(-1.0, 1.0) # 阻力波动
            
            # 持续时间 0.3 秒
            apply_wrench(
                body_name="turtlebot3_waffle::base_footprint", # 或者是您现在的模型名，如 mobile_robot::base_link
                reference_frame="base_footprint", # 相对于车身坐标系
                wrench=wrench,
                start_time=rospy.Time(0),
                duration=rospy.Duration(0.3)
            )
            rospy.loginfo(f"Apply Force Y: {wrench.force.y:.2f} N")
        except rospy.ServiceException as e:
            print("Service call failed: %s"%e)
        
        rate.sleep()

if __name__ == '__main__':
    apply_disturbance()